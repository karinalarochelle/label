# Debug Old Code (A2 & A3)

### Karina Larochelle

#### A2

#### Stack Layout

Show how local variables are allocated on the stack by using gdb after running your program.
```
$ (gdb) bt
```
Copy and paste the output here.

Starting program: /home/csc412-user/labs/labdl/old_code/member1/main2 hola.txt
[Thread debugging using libthread_db enabled]
Using host libthread_db library "/lib/aarch64-linux-gnu/libthread_db.so.1".

Breakpoint 1, main () at main2.c:5
5       int main() {
(gdb) n
7           char filename[] = "unix_sentence.text"; 
(gdb) 
11          file = fopen(filename, "r"); 
(gdb) 
13          while (fgets(buffer, sizeof(buffer), file) != NULL) { 
(gdb) 

Program received signal SIGSEGV, Segmentation fault.
_IO_fgets (buf=0xffffffffef90 "\240\071", <incomplete sequence \367>, n=1024, fp=0x0)
    at iofgets.c:47
47      iofgets.c: No such file or directory.
(gdb) bt
#0  _IO_fgets (buf=0xffffffffef90 "\240\071", <incomplete sequence \367>, n=1024, fp=0x0)
    at iofgets.c:47
#1  0x0000fffff7532fc4 in __interceptor_fgets (
    s=0xffffffffef90 "\240\071", <incomplete sequence \367>, size=<optimized out>, 
    file=<optimized out>)
    at ../../../../src/libsanitizer/sanitizer_common/sanitizer_common_interceptors.inc:1198
#2  0x0000aaaaaaaa0f3c in main () at main2.c:13


#### Improvements and Debugging

**Describe the bugs you found?**
While debugging my code with gdb, I encountered a buffer overflow error. This occurred because I used a fixed-size buffer (char buffer[1024]) to store each line of the file. As a result of this, I faced a segmentation fault when one of the input lines exceeded the size of the buffer I had set, leading to undefined behavior.


**Describe any unsafe code you found?**
Buffer Overflow: As mentioned earlier, using a fixed-size buffer poses a risk of buffer overflow, as described above. Additionally, relying on fixed-size buffers may lead to inefficient memory usage, as memory allocated for the buffer could exceed the actual size of the string being stored. This inefficiency could potentially result in errors or issues later in the program execution.

File Open Error Handling: The code does not check if the file was successfully opened before attempting to read from it. If the file does not exist or can't be opened for any reason, file will be NULL, and attempting to read from it will result in undefined behavior. It's important to check the return value of fopen to ensure the file was opened successfully before proceeding with file operations.

**Describe one improvement made to the code**

#### Fixing a Bug or Improving the Code

Copy your original code as NAME_original.c or NAME_original.cpp.
- sentence_original.c

Implement a fix or improvement identified above. What lines was it implemented?
Handles Lines of Any Length: getline() dynamically resizes the buffer to accommodate lines of any length, ensuring that the entire line is read without truncation. 
- This happens on line 13.

Avoids Buffer Overflow: With dynamic memory allocation, there's no risk of buffer overflow if a line exceeds the buffer size, unlike the fixed-size buffer approach.
Simplifies Memory Management: Using dynamic memory allocation simplifies memory management since you don't have to worry about buffer sizes or potential buffer overflows.
- This happens on line 9 and 10. 

