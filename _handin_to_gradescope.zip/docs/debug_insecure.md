# Debug Insecure Code

### Stack Trace

##### Results with gets()
```
copy and paste here
```

#0  _IO_gets (buf=0xfffffffff440 "`\364\377\377\377\377") at iogets.c:39
#1  0x0000aaaaaaaa1098 in main (argc=1, argv=0xfffffffff5b8) at main.c:36

##### Results with fgets()
```
copy and paste here
```

#0  __interceptor_fgets (s=0xfffffffff440 "`\364\377\377\377\377", size=16, file=0xfffff74db8d0 <_IO_2_1_stdin_>)
    at ../../../../src/libsanitizer/sanitizer_common/sanitizer_common_interceptors.inc:1194
#1  0x0000aaaaaaaa1104 in main (argc=1, argv=0xfffffffff5b8) at main.c:39

##### Describe the differences between the stack traces
The first stack trace relates to the gets() function, shows an error within the _IO_gets() function specifically associated with gets(). On the other hand, the second stack trace pertains to the fgets() function, intercepted by the AddressSanitizer library for memory safety checks, with the error occurring within the __interceptor_fgets() function. These differences extend to the source file/line number and the specific arguments mentioned in each stack trace. Overall, these distinctions show the unique contexts and functions involved in each scenario, illustrating the importance of choosing safe input functions to prevent memory-related issues in C programming.

### Develop your Intution

Answer the questions below as a group.

##### Describe steps on how to recreate to a buffer overflow when gets() is used.
make remake
gdb ./main
b fgets
set follow-fork-mode child
run
n
bt


##### Describe the change in values of buffer, shared_memory, and m as a result of overflow.
The buffer, shared_memory, and m variables are all affected by the buffer overflow caused by the gets() function in the child process. Since gets() doesn't perform bounds checking, it writes beyond the allocated space of buffer. This overwrites adjacent memory regions, potentially affecting other variables. In this case, it may corrupt the shared_memory variable, which is important for inter-process communication, and also modify the value of m. The exact changes in these values will depend on the specific memory layout and the contents of the input.

##### Provide a short intuitive explanation of how gets() causes an error and how fgets() fixes this. 
The gets() function reads characters from the standard input and stores them into the specified buffer until a newline character or end-of-file is hit, without checking the size of the buffer. This makes it vulnerable to buffer overflow, where input larger than the buffer size can overwrite adjacent memory. On the other hand, fgets() reads characters from the standard input and stores them into the specified buffer, but it also specifies a maximum number of characters to read, preventing buffer overflow by ensuring that the input doesn't exceed the buffer size.

##### Provide a short intuitive explanation of how GDB to analyze programs with parent/child processes and shared_memory.
When debugging programs with GDB that involve parent/child processes and shared memory, it's essential to set breakpoints to analyze both parent and child processes. By setting breakpoints at important points in the code, such as before and after fork(), and during memory operations involving shared memory, you can observe how changes in one process affect the other. GDB's ability to debug multi-threaded and multi-process applications allows for thorough analysis of the program's behavior, using detection and resolution of issues related to shared memory and inter-process communication.
